// NPServer1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "windows.h"
#include "process.h"
#include "stdio.h"
#include "conio.h"

LPSTR	lpstrPipeName="\\\\.\\pipe\\$$ThePipe$$";

bool	bTerminateServer;

 

HANDLE	hNamedPipe01;

HANDLE  hControlThread;
unsigned uControlThreadId;

HANDLE	hServiceThread01;
unsigned uServiceThreadId01;

 

unsigned _stdcall ControlConnections(PVOID pParam);	//Thread Function
unsigned _stdcall Service			(PVOID pParam);	//Thread Function

int main(int argc, char* argv[])  
{
	printf("NPServer starting...\n");
//	char   szPipeBuf[260];//	DWORD cbRead;//	DWORD cbWritten;
	//Creating a Null DACL
//The following example creates a mutex with a null DACL.

//If you are creating one of these objects in an application 
//and the object will be shared with a service, 
//you could also use a null DACL to grant everyone access. 
//As an alternative, you could add an access-control entry (ACE) 
//to the DACL that grants access to the user account 
//that the service is running under. 
//This would restrict access to the object to the service. 

PSECURITY_DESCRIPTOR pSD; 
SECURITY_ATTRIBUTES sa; 

pSD = (PSECURITY_DESCRIPTOR) LocalAlloc(LPTR,
      SECURITY_DESCRIPTOR_MIN_LENGTH); 

if (pSD == NULL)
   //Error(...);
   {	printf("CreateNamedPipe: Error=%ld\nInstance %d",GetLastError(),01);
		 
			printf("\nNPServer failed ...\n");
			getch();return 0;
	};

if (!InitializeSecurityDescriptor(pSD, SECURITY_DESCRIPTOR_REVISION))
//   Error(...); 
{	printf("CreateNamedPipe: Error=%ld\nInstance %d",GetLastError(),01);
		 
			printf("\nNPServer failed ...\n");
			getch();return 0;
};

// Add a null DACL to the security descriptor. 
if (!SetSecurityDescriptorDacl(pSD, TRUE, (PACL) NULL, FALSE))
//    Error(...);
{	printf("CreateNamedPipe: Error=%ld\nInstance %d",GetLastError(),01);
		 
			printf("\nNPServer failed ...\n");
			getch();return 0;
};

sa.nLength = sizeof(sa); 
sa.lpSecurityDescriptor = pSD;
sa.bInheritHandle =FALSE ; //TRUE
//mutex = CreateMutex(&sa, FALSE, "SOMENAME"); 
//Microsoft Platform SDK, February 2001 Edition.
//This content last built on Wednesday, February 07, 2001.


//=====Create 01 instance of the named pipe "\\\\.\\pipe\\$$ThePipe$$"=====
 
		hNamedPipe01=CreateNamedPipe(
						lpstrPipeName,
						PIPE_ACCESS_DUPLEX,
						PIPE_TYPE_MESSAGE|PIPE_READMODE_MESSAGE|PIPE_WAIT,
						 PIPE_UNLIMITED_INSTANCES,
						512,512,
						3000,
						&sa);

		if(hNamedPipe01==INVALID_HANDLE_VALUE)
		{	printf("CreateNamedPipe: Error=%ld\nInstance %d",GetLastError(),01);
		 
			printf("\nNPServer failed ...\n");
			getch();return 0;
		}
//	}
///////////////////////////////////////////////////////////////////////////////////
	printf("NPServer created 01 instance of the named pipe ...\n");
//=====End of creating 01 instance of the named pipe "\\\\.\\pipe\\$$ThePipe$$"=====

//=====//  Create Thread to control connection(s) ...

bTerminateServer=false;

hControlThread =(HANDLE)_beginthreadex(NULL,
									   0,//stack size
									   ControlConnections,NULL,
									   0,//not CREATE_SUSPENDED 
									   &uControlThreadId);
if(!hControlThread)	
{
	printf("Creating hControlThread failed ...\n");
	 

	CloseHandle(hNamedPipe01);

	printf("\nNPServer failed ...\n");
	getch();  return 0;
}
/////////////////////////////////////////////////////////////
printf("NPServer waiting for connecting to pipe(s) ...\n");
//=====//End  Creating Thread to control connection(s) ...//=====

printf("To close NPServer press any key...\n");
getch();

/////////////////////////////////////////////////////////////////
//===NPServer is terminating...================================== 

bTerminateServer=true;
//Wait for terminating the thread ControlConnections and others ...

	WaitForSingleObject(hControlThread,10000);//Neaded to check a returned result

	CloseHandle(hControlThread);	//Neaded to check a returned result
			
	printf("Hello World!\nNPServer closed!");
	getch();
	return 0;
}

//THREAD FUNCTION DEFINITION 
unsigned _stdcall ControlConnections(PVOID pParam)
{
	while(!bTerminateServer)
	{
		//DO CONNECTIONS 

		BOOL fConnected;

		if(hNamedPipe01==NULL)
		{
			//There is NO pipe, so is no Service to be available!
			//NPServer fails to run.
			printf("NPServer fails to run. NO PIPES and NO Services. Close it.\n");
			bTerminateServer=true;

			continue;
		}

	//Try to connect NPClient to hNamedPipe01!=NULL 

			//hNamedPipe01 EXISTS!!

		fConnected = ConnectNamedPipe(hNamedPipe01,NULL);

		if(!fConnected)
			{
				switch(GetLastError())
				{
				case ERROR_NO_DATA:   //if a previous client has closed its pipe handle
								      //but the server has not disconnected yet.
				//===Disconnect and reuse the pipe! 
				//===It is possible to connect a new NPClient to hNamedPipes[k].

					if(!DisconnectNamedPipe(hNamedPipe01))
					{
						//?????????What about the thread hServiceThreads[k]
						CloseHandle(hServiceThread01);
						hServiceThread01=NULL;
						//CloseHandle(hNamedPipes[k]);
						//hNamedPipes[k]=NULL;
					}
				////	continue;//for . Next time this	hNamedPipes[k] is free!!			
					break;

				case ERROR_PIPE_CONNECTED://if a client has been connected to the pipe and
										  //it has not closed its handle. 
				//===Skip as the instance is busy!
				////	continue;//for.  This hNamedPipes[k] is busy!!
					break;  
/***************Impossible for blocking mode
				case ERROR_PIPE_LISTENING://if no client is connected,
					break;
				case ERROR_CALL_NOT_IMPLEMENTED:
					break;
****************/
				default:
				//===Error: Close the handle hNamedPipes[k] and Exclude this instance and				 
				//its thread hServiceThreads[k]
					CloseHandle(hNamedPipe01);
					hNamedPipe01=NULL;

					if(hServiceThread01!=NULL)  CloseHandle(hServiceThread01);
					hServiceThread01=NULL;

				////	continue;//for. This hNamedPipes[k] is excluded!!
					break;

				}//switch
			}
			else{
				//hNamedPipe01 connected to a NPClient.				
				//TRY TO Create Thread for servicing the NPClient!!
				//Get client information!
					hServiceThread01 =(HANDLE)_beginthreadex(NULL,0,
														  Service,
														  (PVOID)hNamedPipe01,
														  0,&uServiceThreadId01);
					if(!hServiceThread01)	
					{
						printf("Creating hServiceThread01 failed...\n");
						//Try to Disconnect hNamedPipe01 from the NPClient as 
						//creating hServiceThread01 failed!
						if(!DisconnectNamedPipe(hNamedPipe01))
						{
							printf("Disconnecting hNamedPipe01 failed...\n");
							CloseHandle(hNamedPipe01);
							hNamedPipe01=NULL;
							//hNamedPipe01==NULL, so it is not available!						
						}
						else //hNamedPipe01!=NULL, so it is available!
							printf("Disconnecting hNamedPipe01 ...\n");
						
						//hServiceThread01==NULL always is true!!!

						continue;	//Attempt to create hServiceThread01 again
					}

					printf("\nhNamedPipe01 connected to next NPClient...\n");
					printf("Creating hServiceThread01 ...\n");

					continue;
			}

	}//	while(!bTerminateServer)

	//Prepare to Terminate: Close all handles!!!

		if(hNamedPipe01!=NULL)	CloseHandle(hNamedPipe01);

		if(hServiceThread01!=NULL)	CloseHandle(hServiceThread01);

	printf("NPServer terminating ... Close it.\n");
	return 0;
}//ControlConnections

//THREAD FUNCTION DEFINITION 
unsigned _stdcall Service(PVOID pParam)	//Thread Function
{
	bool bServiceTerminate=false;

	BOOL bReadFile,bWriteFile;

	HANDLE hPipe=(HANDLE)pParam;

	char szBuffer[512];

	DWORD cbRead,cbWritten;
	
	while(!bServiceTerminate)
	{
//================================================================
		    bReadFile=ReadFile(hPipe,szBuffer,512,&cbRead,NULL);
		if(!bReadFile)
		{
			DWORD dwError=GetLastError();
			if(dwError==ERROR_MORE_DATA)
			//The remainder of the message may be read by a subsequent call to the ReadFile
			//or PeekNamedPipe function. 
			//The simplest solution is to ignore the lost of the remainder
			;
			else//??Real Error by Reading: Terminate Service
			{
				printf("ReadFile Error: %ld\n",dwError);
				bServiceTerminate=true;
				continue;
			}
		}
//================================================================
		//Client message has just been read ! A zero-length message means closing NPClient session.
		if (bReadFile &&  cbRead == 0 ) 
		{ 
			// we're at the end of the file
			bServiceTerminate=true;
			//Disconnect hPipe			
			continue;			
		}  
//================================================================		  
		//Get NPClient information!Identify Service and so on!
		printf("Received from NPClient: <<%s>>\n",szBuffer);
		//Get response to the message!
		//Named pipe write operations across a network are limited to 65,535 bytes. 
//================================================================
		bWriteFile = WriteFile(hPipe,szBuffer,strlen(szBuffer)+1,&cbWritten,NULL);
		if(!bWriteFile)
		{//??Real Error by Reading: Terminate Service 
			printf("WriteFile Error: %ld\n",GetLastError());
			bServiceTerminate=true;
			continue;
		}
//================================================================
		//Message exchange to be continued
	}//////////	while(!bServiceTerminate)

	// Service Thread terminating

	DisconnectNamedPipe(hPipe);
	//if disconnecting fails ControlConnections will try to disconnect!		
	
	//Exclude the Service Thread as NPClient session has already ended!
	CloseHandle(hServiceThread01);
	hServiceThread01=NULL;

	printf("hServiceThread01 terminating...\n");
	getch();
//================================================================
	return 0;
}
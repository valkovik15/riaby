// NPClient.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "windows.h"
#include "process.h"
#include "stdio.h"
#include "conio.h"

HANDLE hEchoThread;

unsigned uEchoThreadId;

unsigned _stdcall EchoService(PVOID pParam);	//Thread Function


int main(int argc, char* argv[])
{
	char	szPipeName[260];
	HANDLE	hNamedPipe;

if(argc > 1)sprintf(szPipeName,"\\\\%s\\pipe\\$$ThePipe$$",argv[1]);//Remote Machine Server
else		sprintf(szPipeName,"\\\\.\\pipe\\$$ThePipe$$",argv[1]);//Local Machine Server
 


//Create Pipe from NPClient process to NPServer process

hNamedPipe = CreateFile(szPipeName,GENERIC_READ|GENERIC_WRITE,
						0,   //share mode
						NULL,
						OPEN_EXISTING,
						0,NULL);

if(hNamedPipe==INVALID_HANDLE_VALUE)
{
	printf("CreateFile Error: %ld. NPClient failed ...!\n",GetLastError());
	printf("Press any key to exit.\n");
	getch();
	return 0;
}
/////////////////Named Pipe created/////////
	printf("NPClient connected\n");

//Create EchoService Thread
	hEchoThread =(HANDLE)_beginthreadex(NULL,
									   0,//stack size
									   EchoService,
									   (PVOID)hNamedPipe,
									   0,//not CREATE_SUSPENDED 
									   &uEchoThreadId);
if(!hEchoThread)	
{
	printf("Creating hEchoThread failed ...\n");
	CloseHandle(hNamedPipe);

	printf("\nNPClient failed ...\n");
	getch();  return 0;
}
////EchoServiceThread running ...//////////////////////////////////

printf("NPClient waiting for terminateing EchoServiceThread ...\n"); 

WaitForSingleObject(hEchoThread,INFINITE);//Neaded to check a returned result

CloseHandle(hNamedPipe);				  //Neaded to check a returned result
			
printf("Hello World!\nNPClient closed!\n");
getch();
return 0;
}

unsigned _stdcall EchoService(PVOID pParam) 	//Thread Function
{
	bool bEchoServiceTerminate=false;
	BOOL bReadFile,bWriteFile;
 
	char szBuffer[512];
	DWORD cbRead,cbWritten;
	
	while(!bEchoServiceTerminate)
	{
		printf("Type message:\n");
		gets(szBuffer);
		if(strlen(szBuffer)==0)
		{
			bWriteFile = WriteFile((HANDLE)pParam,szBuffer,strlen(szBuffer),&cbWritten,NULL);
		if(!bWriteFile)
		{//??Real Error by Writing: Terminate Service 
			printf("WriteFile Error: %ld\n",GetLastError());
			bEchoServiceTerminate=true;
			continue;
		}
			bEchoServiceTerminate=true;
			continue;
		}
//====Write to pipe=======================================
//Named pipe write operations across a network are limited to 65,535 bytes. 
		bWriteFile = WriteFile((HANDLE)pParam,szBuffer,strlen(szBuffer)+1,&cbWritten,NULL);
		if(!bWriteFile)
		{//??Real Error by Writing: Terminate Service 
			printf("WriteFile Error: %ld\n",GetLastError());
			bEchoServiceTerminate=true;
			continue;
		}
//====Read from pipe=============================================
		    bReadFile=ReadFile((HANDLE)pParam,szBuffer,512,&cbRead,NULL);
		if(!bReadFile)
		{
			DWORD dwError=GetLastError();
			if(dwError==ERROR_MORE_DATA)
			//The remainder of the message may be read by a subsequent call to the ReadFile
			//or PeekNamedPipe function. 
			//The simplest solution is to ignore the lost of the remainder
			;
			else//??Real Error by Reading: Terminate EchoService
			{
				printf("ReadFile Error: %ld\n",dwError);
				bEchoServiceTerminate=true;
				continue;
			}
		}
//================================================================
		//Server message has just been read !
		//A zero-length message means closing NPClient session.
		if (bReadFile &&  cbRead == 0 ) 
		{ 
			// we're at the end of the file
			bEchoServiceTerminate=true;
			//Disconnect hPipe			
			continue;			
		}  
//====Print Server message======================================		  
		//Get NPServer information!Identify Service and so on!
		printf("Received from NPServer: <<%s>>\n",szBuffer);
//================================================================
		//Message exchange to be continued
	}//////////	while(!bServiceTerminate)

	// EchoService Thread terminating

	DisconnectNamedPipe((HANDLE)pParam);

	printf("hEchoServiceThread  terminating...\n",(int)pParam);
	getch();
//================================================================
	return 0;
}
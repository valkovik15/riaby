// Heaps.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <conio.h>
#include <windows.h>
#include <eh.h>   


int y=101;
void ErrorExit(char *);
void UseNewHeap(void);

int main(int argc, char* argv[])
{
	printf("Use Standart Process Heap!\n");
int *pint;
	pint=new int;	*pint=201;

HANDLE hHeap=GetProcessHeap();

if(!hHeap) 		ErrorExit("GetProcessHeap() Error!");
 
printf("GetProcessHeap() hHeap=%8x\n",hHeap);

int *phint=(int*)HeapAlloc(hHeap,HEAP_ZERO_MEMORY,2);
//sizeof(char)


DWORD dwSize= HeapSize(  hHeap,  // handle to the heap
  HEAP_NO_SERIALIZE, // heap size control flags
   phint  // pointer to memory to return size for LPCVOID
);
if(dwSize==-1)	ErrorExit("HeapSize(...) Error!");
 

printf("HeapSize(...) dwSize=%d!\n",dwSize);

try
{
phint=(int*) HeapReAlloc(
     hHeap ,  // handle to a heap block
  HEAP_GENERATE_EXCEPTIONS|HEAP_REALLOC_IN_PLACE_ONLY|
  HEAP_NO_SERIALIZE|HEAP_ZERO_MEMORY, // heap reallocation flags
    phint,  // pointer to the memory to reallocate
  4  // number of bytes to reallocate
);
	if(!phint) throw("Invalid HeapReAlloc");
}
catch(char * szEx)//
{		 
	 ErrorExit(szEx);   ///throw; 	 
};

	printf("HeapReAlloc(...),from standart heap: *pint=%d\n",*pint);
	printf("\nUse new heap\n");
	UseNewHeap(); 

	printf("Press any key.\n");
	getch();
	return 0;
}

void ErrorExit(char * szMsg)
{
	printf("%s\n",szMsg);
	ExitProcess(1);
}
void UseNewHeap(void)
{
SYSTEM_INFO SystemInfo;

	 GetSystemInfo(  &SystemInfo  ); // address of system information structure   
	 
printf("SystemInfo.dwPageSize: %d\n",SystemInfo.dwPageSize);

 	HANDLE hHeap=HeapCreate(0,     //thread-safe access (HEAP_NO_SERIALIZE)
		                    2*SystemInfo.dwPageSize,  //Committed
		                   20*SystemInfo.dwPageSize); //Reserved ;It isn't growable.
													//0 means it is growable!
	if(!hHeap) ErrorExit("No HeapCreate.");

printf("HeapCreate() hHeap=%8x\n",hHeap);
int *phint=(int*)HeapAlloc(hHeap,HEAP_ZERO_MEMORY,10*sizeof(int));
  
	if(!phint) ErrorExit("Not allocated a memory under int(*)[10].");

	DWORD dwSize= HeapSize(  hHeap,  // handle to the heap
  HEAP_NO_SERIALIZE, // heap size control flags
   phint  // pointer to memory to return size for LPCVOID
);

if(dwSize==-1)	ErrorExit("HeapSize(..,phint) Error!");

printf("HeapSize(..,phint) dwSize=%d!\n",dwSize);
/*Windows 98 :unsupported
HANDLE hbufHeaps[4];
DWORD numHeaps=GetProcessHeaps(
  4,  // maximum number of heap handles buffer can receive
    hbufHeaps  // pointer to buffer to receive heap handles
);
if(numHeaps==0)ErrorExit("GetProcessHeaps(4,hbufHeaps) Error!");
 
printf("numHeaps=%d\n",numHeaps); 
*/
	if(! HeapFree(hHeap,  // handle to the heap
				  0, // heap freeing flags:0 means a thread-safe access
				phint)   // pointer to the memory to free
	  )	ErrorExit("HeapFree(..,phint) Error!");

printf("HeapFree(..,phint) is successful\n");


/*
DWORD numHeaps=GetProcessHeaps(
  4,  // maximum number of heap handles buffer can receive
    hbufHeaps  // pointer to buffer to receive heap handles
);
if(numHeaps==0)ErrorExit("GetProcessHeaps(4,hbufHeaps) Error!");
 
printf("numHeaps=%d\n",numHeaps); 
*/
   if(! HeapDestroy(  hHeap ))// handle to the heap
	                          //Don't destroy the Standart Process Heap
   ErrorExit("HeapDestroy(hHeap) Error!"); 

printf("HeapDestroy(  hHeap )\n");   
printf("\nDon't destroy the Standart Process Heap\n");   
}
